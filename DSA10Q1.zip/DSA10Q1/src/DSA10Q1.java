
public class DSA10Q1 {
	
	    public static boolean isPowerOfThree(int n) {
	        if (n == 0) {
	            return false; // Base case: not a power of three
	        }
	        
	        if (n == 1) {
	            return true; // Base case: n is 3^0
	        }
	        
	        if (n % 3 != 0) {
	            return false; // Base case: n is not divisible by 3
	        }
	        
	        return isPowerOfThree(n / 3); // Recursively check if n/3 is a power of three
	    }
	    
	    public static void main(String[] args) {
	        //int n = 0;
	    	int n=27;
	        boolean result = isPowerOfThree(n);
	        System.out.println(result);
	    }
	

}
