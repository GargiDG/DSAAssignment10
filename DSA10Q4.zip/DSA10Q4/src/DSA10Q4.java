
public class DSA10Q4 {

	    public static int calculateLength(String str) {
	        if (str.equals("")) {
	            return 0; // Base case: Empty string has length 0
	        }
	        
	        return 1 + calculateLength(str.substring(1)); // Recursively calculate length of the substring starting from index 1
	    }
	    
	    public static void main(String[] args) {
	        String str = "GEEKSFORGEEKS";
	        int length = calculateLength(str);
	        System.out.println(length);
	    }
	}
