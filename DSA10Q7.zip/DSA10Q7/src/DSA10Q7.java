
public class DSA10Q7 {

	    public static void printPermutations(String str) {
	        printPermutationsHelper(str, 0, str.length() - 1);
	    }
	    
	    private static void printPermutationsHelper(String str, int left, int right) {
	        if (left == right) {
	            System.out.println(str); // Base case: Print the permutation
	            return;
	        }
	        
	        for (int i = left; i <= right; i++) {
	            str = swap(str, left, i); // Swap characters at positions left and i
	            printPermutationsHelper(str, left + 1, right); // Recursively generate permutations for the remaining characters
	            str = swap(str, left, i); // Restore the original order by swapping back the characters
	        }
	    }
	    
	    private static String swap(String str, int i, int j) {
	        char[] charArray = str.toCharArray();
	        char temp = charArray[i];
	        charArray[i] = charArray[j];
	        charArray[j] = temp;
	        return String.valueOf(charArray);
	    }
	    
	    public static void main(String[] args) {
	        String str = "abb";
	        printPermutations(str);
	    }
	}
