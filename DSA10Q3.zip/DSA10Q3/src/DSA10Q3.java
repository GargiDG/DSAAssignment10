import java.util.ArrayList;
import java.util.List;

public class DSA10Q3 {

	    public static List<String> generateSubsets(String set) {
	        List<String> subsets = new ArrayList<>();
	        generateSubsetsHelper(set, "", 0, subsets);
	        return subsets;
	    }
	    
	    private static void generateSubsetsHelper(String set, String currentSubset, int index, List<String> subsets) {
	        if (index == set.length()) {
	            subsets.add(currentSubset); // Base case: Add current subset to the list of subsets
	            return;
	        }
	        
	        generateSubsetsHelper(set, currentSubset, index + 1, subsets); // Exclude current character
	        
	        String newSubset = currentSubset + set.charAt(index);
	        generateSubsetsHelper(set, newSubset, index + 1, subsets); // Include current character
	    }
	    
	    public static void main(String[] args) {
	        String set = "abc";
	        List<String> subsets = generateSubsets(set);
	        System.out.println(subsets);
	    }
	}
