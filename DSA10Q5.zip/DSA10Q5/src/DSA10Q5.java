
public class DSA10Q5 {

	    public static int countSubstrings(String str) {
	        return countSubstringsHelper(str, 0, str.length() - 1);
	    }
	    
	    private static int countSubstringsHelper(String str, int start, int end) {
	        if (start > end) {
	            return 0; // Base case: Empty string or invalid range
	        }
	        
	        int count = countSubstringsHelper(str, start + 1, end) + countSubstringsHelper(str, start, end - 1)
	                - countSubstringsHelper(str, start + 1, end - 1); // Recursively count substrings
	        
	        if (str.charAt(start) == str.charAt(end)) {
	            count++; // Increment count if the start and end characters are the same
	        }
	        
	        return count;
	    }
	    
	    public static void main(String[] args) {
	        String str = "abcab";
	        int count = countSubstrings(str);
	        System.out.println(count);
	    }
	}

