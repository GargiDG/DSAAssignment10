
public class DSA10Q6 {
	    public static void towerOfHanoi(int n, char source, char destination, char auxiliary) {
	        if (n == 1) {
	            System.out.println("Move disk 1 from " + source + " to " + destination);
	            return;
	        }
	        
	        towerOfHanoi(n - 1, source, auxiliary, destination); // Move n-1 disks from source to auxiliary
	        System.out.println("Move disk " + n + " from " + source + " to " + destination); // Move the nth disk from source to destination
	        towerOfHanoi(n - 1, auxiliary, destination, source); // Move n-1 disks from auxiliary to destination
	    }
	    
	    public static int countMoves(int n) {
	        if (n == 1) {
	            return 1;
	        }
	        
	        return 2 * countMoves(n - 1) + 1;
	    }
	    
	    public static void main(String[] args) {
	        int n = 2;
	        towerOfHanoi(n, 'A', 'C', 'B');
	        
	        int totalMoves = countMoves(n);
	        System.out.println("Total moves: " + totalMoves);
	    }
	}
