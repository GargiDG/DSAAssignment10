
public class DSA10Q2 {
	    public static int lastRemaining(int n) {
	        return lastRemainingHelper(n, true);
	    }
	    
	    private static int lastRemainingHelper(int n, boolean isLeftToRight) {
	        if (n == 1) {
	            return 1; // Base case: Only one number remaining
	        }
	        
	        if (isLeftToRight) {
	            // When traversing from left to right, the next number after removing every other number is obtained by doubling
	            // For example, if the sequence is 1, 2, 3, 4, 5, 6, 7, 8, 9, after removing every other number we have 2, 4, 6, 8
	            // The next number after doubling is 2 * (next number after removing every other number)
	            return 2 * lastRemainingHelper(n / 2, false);
	        } else {
	            // When traversing from right to left, the next number after removing every other number is obtained by doubling and subtracting 1
	            // For example, if the sequence is 2, 4, 6, 8, after removing every other number we have 2, 6
	            // The next number after doubling and subtracting 1 is 2 * (next number after removing every other number) - 1
	            return 2 * lastRemainingHelper(n / 2, true) - 1;
	        }
	    }
	    
	    public static void main(String[] args) {
	        int n = 9;
	        int result = lastRemaining(n);
	        System.out.println(result);
	    }
	}

